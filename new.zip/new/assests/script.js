function loadForm(formName) {
    let formContent = '';

    if (formName === 'form1') {
        formContent = `
        <h4>Photo Labs/Photo Studios Registration Form</h4>
        <form>
            <!-- Add form1 fields here -->
        </form>`;
    } else if (formName === 'form2') {
        formContent = `
        <h4>TV Game Registration Form</h4>
        <form>
            <!-- Add form2 fields here -->
        </form>`;
    }
    // Add more conditions for additional forms

    document.getElementById('formContent').innerHTML = formContent;
}