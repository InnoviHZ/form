<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include "./fpdf/fpdf.php";
include './config/config.php';

if (isset($_POST['submit'])) {
    // Collect form data
    $applicant_name = $_POST['name'];
    $address = $_POST['address'];
    $nationality = $_POST['nationality'];
    $state = $_POST['state'];
    $local_gov = $_POST['localGovt'];
    $phone_number = $_POST['phoneNo'];
    $age = $_POST['age'];
    $shop_name = $_POST['shopName'];
    $shop_address = $_POST['shopAddress'];
    $association_name = $_POST['associationName'];
    $association_signing = $_POST['associationStamp'];
    $gsm_no = $_POST['gsmNo'];
    $name = $_POST['name2'];
    $applicantSignature = $_POST['applicantSignature'];
    $gsm = $_POST['gsm'];

    // Prepare the SQL insert statement
    $insertQuery = "INSERT INTO `photo_studio`(`applicant_name`, `address`, `nationality`, `state`, `local_gov`, `phone_number`, `age`, `shop_name`, `shop_address`, `association_name`, `association_signing`, `gsm_no`, `name`, `applicantSignature`, `gsm`)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = mysqli_prepare($conn, $insertQuery);
    mysqli_stmt_bind_param($stmt, "ssssssissssssss", $applicant_name, $address, $nationality, $state, $local_gov, $phone_number, $age, $shop_name, $shop_address, $association_name, $association_signing, $gsm_no, $name, $applicantSignature, $gsm);

    // Execute the statement
    if (mysqli_stmt_execute($stmt)) {
        generate_pdf();
    } else {
        echo "Error: " . mysqli_error($conn);
    }

    // Close the statement
    mysqli_stmt_close($stmt);
}

function generate_pdf()
{
    // make all valiable global
    global $applicant_name ;
    global $address ;
    global $nationality ;
    global $state ;
    global $local_gov ;


    $pdf = new FPDF();
    $pdf->AddPage("P" , "A4", "0");

    $pdf->Image('image.jpeg', 0, 0, 210, 297);

    $pdf->SetFont('Arial', '', 12);
    $pdf->Cell(90, 180, $applicant_name , 0, 0, 'R');

    $pdf->SetFont('Arial', '', 12);
    $pdf->Cell(90, 200, $address , 0, 0, 'R');

    $pdf->SetFont('Arial', '', 12);
    $pdf->Cell(90, 210, $nationality , 0, 0, 'R');

    $pdf->SetFont('Arial', '', 12);
    $pdf->Cell(110, 210, $state , 0, 0, 'R');

    $pdf->SetFont('Arial', '', 12);
    $pdf->Cell(130, 210, $local_gov , 0, 0, 'R');

    $pdf->Output('sample.pdf' , 'D');
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kano State Censorship Board Form</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <style>
        .form-header {
            text-align: center;
            margin-bottom: 20px;
        }

        .rules {
            border: 1px solid #000;
            padding: 10px;
            margin-top: 20px;
            border-radius: 5px;
        }

        .attestation {
            margin-top: 20px;
        }

        .input {
            height: 50px;
        }

        .form-container {
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            background-color: #f9f9f9;
            max-width: 800px;
            margin-top: 50px;
        }
    </style>
</head>

<body class="p-3">
    <div class="container form-container m-auto p-5 shadow-lg rounded border-opacity-10 w-100">
        <div class="form-header">
            <h4>PHOTO LABS/PHOTO STUDIOS REGISTRATION FORM</h4>
        </div>

        <form method="post">
            <div class="form-group row">
                <div class="col-md-12 mb-3">
                    <input type="text" class="form-control input" name="name" placeholder="Name of Applicant" required>
                </div>
            </div>
            <div class="form-group row">
                <div class="col-12 mb-3">
                    <input type="text" class="form-control input" name="address" id="address" placeholder="Address" required>
                </div>
            </div>
            <div class="form-group row">
                <div class="col-md-4 mb-3">
                    <select id="nationality" name="nationality" class="form-select form-control input" required>
                        <option selected disabled value="">Nationality</option>
                        <option value="ghana">Ghana</option>
                        <option value="niger">Niger</option>
                        <option value="nigeria">Nigeria</option>
                        <option value="usa">USA</option>
                    </select>
                </div>
                <div class="col-md-4 mb-3">
                    <select id="state" name="state" class="form-select form-control input" required>
                        <option selected disabled value="">State</option>
                        <option value="kano">Kano</option>
                        <option value="lagos">Lagos</option>
                        <option value="abuja">Abuja</option>
                        <option value="kaduna">Kaduna</option>
                    </select>
                </div>
                <div class="col-md-4 mb-3">
                    <select id="localGovt" name="localGovt" class="form-select form-control input" required>
                        <option selected disabled value="">Local Govt.</option>
                        <option value="kano">Kano</option>
                        <option value="lagos">Lagos</option>
                        <option value="abuja">Abuja</option>
                        <option value="kaduna">Kaduna</option>
                    </select>
                </div>
            </div>
            <div class="form-group row">
                <div class="col-md-8 mb-3">
                    <input type="tel" class="form-control input" name="phoneNo" id="phoneNo" placeholder="Phone No." required>
                </div>
                <div class="col-md-4 mb-3">
                    <input type="number" class="form-control input" name="age" placeholder="Age" min="18" required>
                </div>
            </div>
            <div class="form-group row">
                <div class="col-12 mb-3">
                    <input type="text" class="form-control input" name="shopName" placeholder="Shop Name" required>
                </div>
            </div>
            <div class="form-group row">
                <div class="col-12 mb-3">
                    <input type="text" class="form-control input" name="shopAddress" placeholder="Shop Address" required>
                </div>
            </div>
            <div class="form-group row">
                <div class="col-12 mb-3">
                    <input type="text" class="form-control input" name="associationName" placeholder="Name of Association" required>
                </div>
            </div>
            <div class="form-group row">
                <div class="col-12 mb-3">
                    <input type="text" class="form-control input" name="associationStamp" placeholder="Signing & Stamp of Association" required>
                </div>
            </div>
            <div class="form-group row">
                <div class="col-12 mb-3">
                    <input type="tel" class="form-control input" name="gsmNo" placeholder="G.S.M No." required>
                </div>
            </div>

            <div class="rules">
                <h5>THE BOARD RULES AND REGULATIONS</h5>
                <ol>
                    <li>Printing of all Pornographic content is strictly prohibited.</li>
                    <li>No forgery of any content whether document or ID Card without prior permission of the owner.</li>
                    <li>Photo editing and image producing which is offensive to others is strictly prohibited.</li>
                    <li>The above-mentioned rules and regulations are subject to addition or change where it deems necessary by the Board.</li>
                </ol>
            </div>

            <div class="attestation">
                <p><strong>ATTESTATION</strong></p>
                <p>I, <input type="text" name="name2" style="border: none; border-bottom: 1px solid #000;" placeholder="Your Name" required>, agree to comply with the above rules and regulations. Failure to comply may result in legal action against me.</p>
                <div class="form-group row">
                    <div class="col-md-6 mb-3">
                        <input type="text" class="form-control input" name="applicantSignature" placeholder="Upload Signature" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <input type="tel" class="form-control input" name="gsm" placeholder="G.S.M" required>
                    </div>
                </div>
            </div>
            <div class="mt-5">
                <button type="submit" name="submit" class="btn btn-primary w-100">Apply</button>
            </div>
        </form>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>