<?Php
$host_name = "localhost";
$database = "my_db";
$username = "root";
$password = "";

$conn = mysqli_connect($host_name, $username, $password, $database);

if (!$conn) {
    echo "Error: Unable to connect to MySQL.<br>";
    echo "<br>Debugging errno: " . mysqli_connect_errno();
    echo "<br>Debugging error: " . mysqli_connect_error();
    exit;
}